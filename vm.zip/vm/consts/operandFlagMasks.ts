export const OPCODE_MASK = 2047; // 11 единичных разрядов.
export const DOUBLE_OPERAND_FLAG_MASK = 2048; // 1 << 11
// const LONG_OPERAND_FLAG_MASK = 4096; //1 << 12
export const STRING_OPERAND_FLAG_MASK = 8192; // 1 << 13;
export const OTHER_OPERAND_FLAG_MASK = 16384; // 1 << 14
